import { ICliente } from "@/app/model/VentaModel";
import { obtenerCliente } from "@/app/service/ClienteService";
import { Button, Table } from "flowbite-react";
import { useEffect, useState } from "react";
import { HiUserAdd } from "react-icons/hi";

const ListCliente: React.FC = () => {
  const [listCliente, setListCliente] = useState<ICliente[]>([]);

  useEffect(() => {
    const get = async () => {
      try {
        setListCliente(await obtenerCliente());
      } catch (error) {
        console.log(error);
      }
    };
    get();
  }, []);

  return (
    <>
      <div className="flex flex-row justify-between">
        <div className="text-gray-700 text-2xl font-semibold dark:text-gray-300 mb-1">
          Lista de Clientes
        </div>
        <Button
          onClick={() => {
            // setOpenModalNew(true);
          }}
        >
          <div className="my-auto">Registrar nuevo Cliente</div>
          <div className="my-auto ml-3">
            <HiUserAdd size={20} />
          </div>
        </Button>
      </div>
      <div className="w-64 border-2 mb-5 border-[#6DB26D]"></div>
      <div className="overflow-x-auto slide-in-fwd-center">
        <Table>
          <Table.Head className="text-center">
            <Table.HeadCell>Nombre Cliente</Table.HeadCell>
            <Table.HeadCell>Apellidos</Table.HeadCell>
            <Table.HeadCell>Dirección</Table.HeadCell>
            <Table.HeadCell>Tipo de Identificación</Table.HeadCell>
            <Table.HeadCell>Número de Identificación</Table.HeadCell>
            <Table.HeadCell>Número de Contacto</Table.HeadCell>
            {/* <Table.HeadCell>Fecha</Table.HeadCell> */}
            {/* <Table.HeadCell>Estado</Table.HeadCell> */}
            <Table.HeadCell>
              <span className="sr-only">Ver detalle</span>
            </Table.HeadCell>
            <Table.HeadCell>
              <span className="sr-only">Edit</span>
            </Table.HeadCell>
            <Table.HeadCell>
              <span className="sr-only">Delete</span>
            </Table.HeadCell>
          </Table.Head>
          <Table.Body className="divide-y text-center">
            {listCliente.map((item, i) => (
              <Table.Row
                className="bg-white dark:border-gray-700 dark:bg-gray-800"
                key={item.idCliente}
              >
                <Table.Cell className="whitespace-nowrap font-medium text-gray-900 dark:text-white">
                  {item.persona.nombres}
                </Table.Cell>
                <Table.Cell>
                  {item.persona.apellidoPaterno +
                    " " +
                    item.persona.apellidoMaterno}
                </Table.Cell>
                <Table.Cell>{item.persona.direccion}</Table.Cell>
                <Table.Cell>{item.persona.codTipoIdentificacion}</Table.Cell>
                <Table.Cell>{item.persona.numeroIdentificacion}</Table.Cell>
                <Table.Cell>{item.persona.numeroContacto}</Table.Cell>
                {/* <Table.Cell>
                {format(parseISO(item.fecRegistro), "dd/MM/yyyy")}
              </Table.Cell> */}
                {/* <Table.Cell>{item.estado}</Table.Cell> */}
                <Table.Cell>
                  <a
                    href="#"
                    className="font-medium text-cyan-600 hover:underline dark:text-cyan-500"
                    onClick={() => {
                      //   setIdProducto(item.idProducto);
                      //   setOpenModalView(true);
                    }}
                  >
                    Ver detalles
                  </a>
                </Table.Cell>
                <Table.Cell>
                  <a
                    href="#"
                    className="font-medium text-cyan-600 hover:underline dark:text-cyan-500"
                    onClick={() => {}}
                  >
                    Editar
                  </a>
                </Table.Cell>
                <Table.Cell>
                  <a
                    href="#"
                    className="font-medium text-cyan-600 hover:underline dark:text-cyan-500"
                    onClick={async () => {
                      //   setIdProducto(item.idProducto);
                      //   setOpenModalDelete(true);
                    }}
                  >
                    Eliminar
                  </a>
                </Table.Cell>
              </Table.Row>
            ))}
          </Table.Body>
        </Table>
      </div>
    </>
  );
};

export default ListCliente;
