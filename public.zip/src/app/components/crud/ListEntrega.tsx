import { IEntrega } from "@/app/model/IEntregaModel";
import { obtenerEntregas } from "@/app/service/EntregaService";
import { obtenerEstado, obtenerNombreDominio } from "@/app/utils/Utils";
import { Table } from "flowbite-react";
import { useEffect, useState } from "react";

const ListEntrega: React.FC = () => {
  const [listEntrega, setListaEntrega] = useState<IEntrega[]>([]);

  useEffect(() => {
    const get = async () => {
      try {
        setListaEntrega(await obtenerEntregas());
      } catch (error) {
        console.log(error);
      }
    };
    get();
  }, []);

  return (
    <div className="overflow-x-auto h-80 overflow-y-auto">
      <Table>
        <Table.Head>
          <Table.HeadCell className="bg-[#594C4D] dark:bg-[#594C4D] dark:text-white text-center text-white">
            Nombre Repartidor
          </Table.HeadCell>
          <Table.HeadCell className="bg-[#594C4D] dark:bg-[#594C4D] dark:text-white text-center text-white">
            Nombre Cliente
          </Table.HeadCell>
          <Table.HeadCell className="bg-[#594C4D] dark:bg-[#594C4D] dark:text-white text-center text-white">
            Precio Total de la venta
          </Table.HeadCell>
          <Table.HeadCell className="bg-[#594C4D] dark:bg-[#594C4D] dark:text-white text-center text-white">
            Estado
          </Table.HeadCell>
          <Table.HeadCell className="bg-[#594C4D] dark:bg-[#594C4D] dark:text-white text-center text-white">
            <span className="sr-only">Edit</span>
          </Table.HeadCell>
        </Table.Head>
        <Table.Body className="divide-y">
          {listEntrega.map((item) => (
            <Table.Row
              className="bg-[#DFDFDF] dark:border-gray-700 dark:bg-[#DFDFDF] text-gray-600 dark:text-[#431A33]"
              key={item.idEntrega}
            >
              <Table.Cell className="text-center px-1">
                {item.repartidor.persona.nombres +
                  " " +
                  item.repartidor.persona.apellidoPaterno}
              </Table.Cell>
              <Table.Cell className="text-center px-1">
                {item.venta.cliente.persona.nombres +
                  " " +
                  item.venta.cliente.persona.apellidoPaterno +
                  " " +
                  item.venta.cliente.persona.apellidoMaterno}
              </Table.Cell>
              <Table.Cell className="text-center px-1">
                {item.venta.total}
              </Table.Cell>
              <Table.Cell className="text-center px-1">
                {obtenerEstado(item.codEstado)}
              </Table.Cell>
              <Table.Cell className="px-1 text-center text-nowrap pr-3">
                <a
                  href="#"
                  className="font-medium text-cyan-600 hover:underline dark:text-cyan-700"
                >
                  Ver Detalles
                </a>
              </Table.Cell>
            </Table.Row>
          ))}
        </Table.Body>
      </Table>
    </div>
  );
};

export default ListEntrega;
