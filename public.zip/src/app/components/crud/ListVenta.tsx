import { IVenta } from "@/app/model/VentaModel";
import { obtenerTodasVentas } from "@/app/service/VentaService";
import { format, parseISO } from "date-fns";
import { Button, Table } from "flowbite-react";
import { useEffect, useState } from "react";

const ListVenta: React.FC = () => {
  const [listVenta, setListaVenta] = useState<IVenta[]>([]);

  useEffect(() => {
    const get = async () => {
      try {
        setListaVenta(await obtenerTodasVentas());
      } catch (error) {
        console.log(error);
      }
    };
    get();
  }, []);

  return (
    <>
      <div className="flex flex-row justify-between">
        <div className="text-gray-700 text-2xl font-semibold dark:text-gray-300 mb-1">
          Lista de Ventas
        </div>
      </div>
      <div className="w-64 border-2 mb-5 border-[#6DB26D]"></div>
      <div className="overflow-x-auto slide-in-fwd-center">
        <Table>
          <Table.Head className="text-center">
            <Table.HeadCell>Número de Comprobante</Table.HeadCell>
            <Table.HeadCell>Total Compra</Table.HeadCell>
            <Table.HeadCell>Método de Pago</Table.HeadCell>
            <Table.HeadCell>Tipo de Venta</Table.HeadCell>
            <Table.HeadCell>Cliente</Table.HeadCell>
            <Table.HeadCell>Usuario vendedor</Table.HeadCell>
            <Table.HeadCell>Fecha</Table.HeadCell>
            <Table.HeadCell>Estado</Table.HeadCell>
            <Table.HeadCell>
              <span className="sr-only">Ver detalle</span>
            </Table.HeadCell>
          </Table.Head>
          <Table.Body className="divide-y text-center">
            {listVenta.map((item, i) => (
              <Table.Row
                className="bg-white dark:border-gray-700 dark:bg-gray-800"
                key={item.numComprobante}
              >
                <Table.Cell>{item.numComprobante}</Table.Cell>
                <Table.Cell className="whitespace-nowrap font-medium text-gray-900 dark:text-white">
                  {item.total}
                </Table.Cell>
                <Table.Cell>{item.codMetodoPago}</Table.Cell>
                <Table.Cell>{item.codTipoVenta}</Table.Cell>
                <Table.Cell>
                  {item.cliente.persona.nombres +
                    " " +
                    item.cliente.persona.apellidoPaterno +
                    " " +
                    item.cliente.persona.apellidoMaterno}
                </Table.Cell>
                <Table.Cell>
                  {item.user.persona.nombres +
                    " " +
                    item.user.persona.apellidoPaterno +
                    " " +
                    item.user.persona.apellidoMaterno}
                </Table.Cell>
                <Table.Cell>
                  {format(parseISO(item.fecRegistro), "dd/MM/yyyy")}
                </Table.Cell>

                <Table.Cell>{item.estado}</Table.Cell>
                <Table.Cell>
                  <a
                    href="#"
                    className="font-medium text-cyan-600 hover:underline dark:text-cyan-500"
                    onClick={() => {
                      //   setIdProducto(item.idProducto);
                      //   setOpenModalView(true);
                    }}
                  >
                    Ver detalles
                  </a>
                </Table.Cell>
               
              </Table.Row>
            ))}
          </Table.Body>
        </Table>
      </div>
    </>
  );
};

export default ListVenta;
