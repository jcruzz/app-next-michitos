import { IDominioFijo } from "@/app/model/DominioModel";
import { IEntregav2 } from "@/app/model/IEntregaModel";
import { IProducto } from "@/app/model/ProductModel";
import { ICliente, IDetalleVenta, IUser, IVenta } from "@/app/model/VentaModel";
import {
  obtenerCliente,
  obtenerClienteById,
} from "@/app/service/ClienteService";
import {
  obtenerDominioMetodoPago,
  obtenerTipoVenta,
} from "@/app/service/DominioService";
import { guardarEntrega } from "@/app/service/EntregaService";
import {
  obtenerProducto,
  obtenerProductos,
} from "@/app/service/ProductService";
import {
  obtenerDatosUsuario,
  obtenerUsuarioPorId,
  obtenerUsuarios,
} from "@/app/service/UserService";
import { guardarVenta } from "@/app/service/VentaService";
import { useAlert } from "@/app/utils/usAlert";
import { Button, Checkbox, Label, Select, TextInput } from "flowbite-react";
import { useEffect, useRef, useState } from "react";

interface DetalleVenta {
  producto: string;
  cantidad: number;
  precio: number;
}

const NewVenta: React.FC = () => {
  const [detalles, setDetalles] = useState<DetalleVenta[]>([]);
  const [nuevoDetalle, setNuevoDetalle] = useState<DetalleVenta>({
    producto: "",
    cantidad: 1,
    precio: 0,
  });

  const checkRepartidor = useRef<HTMLInputElement>(null);

  const handleCheckRepartidor = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    if (event.target.checked) {
      setDisableRepartidor(false);
    } else {
      setDisableRepartidor(true);
      setRepartidorOption("");
    }
  };

  const [cliente, setClientes] = useState<ICliente[]>([]);
  const [tipoPago, setTipoPago] = useState<IDominioFijo[]>([]);
  const [tipoVenta, setTipoVenta] = useState<IDominioFijo[]>([]);
  const [producto, setProducto] = useState<IProducto[]>([]);
  const [repartidores, setRepartidores] = useState<IUser[]>([]);

  const [disableRepartidor, setDisableRepartidor] = useState<boolean>(true);

  const { showAlert } = useAlert();

  const [repartidorOption, setRepartidorOption] = useState<string>("");

  const handleSelectChangeRepartidor = (
    event: React.ChangeEvent<HTMLSelectElement>
  ) => {
    const selectedValue = event.target.value; // Obtiene el valor seleccionado
    setRepartidorOption(selectedValue);
  };

  const [optionCliente, setOptionCliente] = useState<string>("");

  const handleSelectChangeCliente = (
    event: React.ChangeEvent<HTMLSelectElement>
  ) => {
    const selectedValue = event.target.value; // Obtiene el valor seleccionado
    setOptionCliente(selectedValue);
  };

  const [tipoVentaOption, setTipoVentaOption] = useState<string>("");

  const handleSelectChangeTipoVenta = (
    event: React.ChangeEvent<HTMLSelectElement>
  ) => {
    const selectedValue = event.target.value; // Obtiene el valor seleccionado
    setTipoVentaOption(selectedValue);
  };

  const [tipPagoOption, setTipPagoOption] = useState<string>("");

  const handleSelectChangeTipoPago = (
    event: React.ChangeEvent<HTMLSelectElement>
  ) => {
    const selectedValue = event.target.value; // Obtiene el valor seleccionado
    setTipPagoOption(selectedValue);
  };

  useEffect(() => {
    const get = async () => {
      try {
        setClientes(await obtenerCliente());
        setTipoPago(await obtenerDominioMetodoPago());
        setTipoVenta(await obtenerTipoVenta());
        setProducto(await obtenerProductos());
        setRepartidores(await obtenerUsuarios());
      } catch (error) {
        console.log(error);
      }
    };
    get();
  }, []);

  const agregarDetalle = () => {
    if (
      !nuevoDetalle.producto ||
      nuevoDetalle.cantidad <= 0 ||
      nuevoDetalle.precio <= 0
    ) {
      alert("Todos los campos son obligatorios y deben tener valores válidos.");
      return;
    }
    setDetalles([...detalles, nuevoDetalle]);
    setNuevoDetalle({ producto: "", cantidad: 1, precio: 0 });
  };

  const eliminarDetalle = (index: number) => {
    const nuevosDetalles = detalles.filter((_, i) => i !== index);
    setDetalles(nuevosDetalles);
  };

  const totalVenta = detalles.reduce(
    (total, detalle) => total + detalle.cantidad * detalle.precio,
    0
  );

  const submitForm = async () => {
    try {
      let detallesLista: IDetalleVenta[] = [];

      for (let i = 0; i < detalles.length; i++) {
        let det: IDetalleVenta = {
          cantidad: detalles[i].cantidad,
          codEstado: "ACT",
          fecRegistro: "",
          precioVenta: detalles[i].precio,
          producto: await obtenerProducto(Number(detalles[i].producto)),
        };
        detallesLista.push(det);
      }

      const venta: IVenta = {
        idVenta: null,
        cliente: await obtenerClienteById(Number(optionCliente)),
        codMetodoPago: tipPagoOption,
        codTipoVenta: tipoVentaOption,
        detalles: detallesLista,
        estado: "ACT",
        fecRegistro: "",
        numComprobante: Math.floor(100000 + Math.random() * 900000),
        total: Number(totalVenta.toFixed(2)),
        user: await obtenerDatosUsuario(),
      };

      const resp = await guardarVenta(venta);

      if (checkRepartidor.current?.checked) {
        const entrega: IEntregav2 = {
          codEstado: "",
          fecRegistro: "",
          idEntrega: null,
          repartidor: await obtenerUsuarioPorId(Number(repartidorOption)),
          venta: resp
        }

        await guardarEntrega(entrega);
      }
      
      showAlert("Success", "Registro guardado correctamente");
    } catch (error) {
      console.log(error);

      showAlert("Error", "Error al guardar el registro");
    }
  };

  return (
    <div className="p-6 bg-[#F4EEF3]">
      <div className="max-w-4xl mx-auto">
        <div className="px-6">
          <h3 className="text-lg font-medium text-gray-800 mb-2 dark:text-gray-800">
            Datos de la Venta
          </h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <Label
                htmlFor="cliente"
                value="Cliente"
                className="dark:text-gray-800"
              />
              <Select
                id="cliente"
                className="col-span-2"
                onChange={handleSelectChangeCliente}
                value={optionCliente}
              >
                <option value={"default"} selected></option>
                {cliente.map((item) => (
                  <option value={item.idCliente}>
                    {item.persona.nombres +
                      " " +
                      item.persona.apellidoPaterno +
                      " " +
                      item.persona.apellidoMaterno +
                      " " +
                      item.persona.codTipoIdentificacion +
                      " " +
                      item.persona.numeroIdentificacion}
                  </option>
                ))}
              </Select>
            </div>
            <div>
              <Label
                htmlFor="tipoVenta"
                value="Tipo de Venta"
                className="dark:text-gray-800"
              />
              <Select
                id="tipoVenta"
                className="col-span-2"
                onChange={handleSelectChangeTipoVenta}
                value={tipoVentaOption}
              >
                <option value={"default"} selected></option>
                {tipoVenta.map((item) => (
                  <option value={item.codDominio}>{item.nombreDominio}</option>
                ))}
              </Select>
            </div>
            <div>
              <Label
                htmlFor="tipoPago"
                value="Método de Pago"
                className="dark:text-gray-800"
              />
              <Select
                id="tipoPago"
                className="col-span-2"
                onChange={handleSelectChangeTipoPago}
                value={tipPagoOption}
              >
                <option value={"default"} selected></option>
                {tipoPago.map((item) => (
                  <option value={item.codDominio}>{item.nombreDominio}</option>
                ))}
              </Select>
            </div>
            <div>
              <Label
                htmlFor="tipoPago"
                value="Repartidor"
                className="dark:text-gray-800"
              />
              <Select
                id="repartidorId"
                className="col-span-2"
                onChange={handleSelectChangeRepartidor}
                value={repartidorOption}
                disabled={disableRepartidor}
              >
                <option value={"default"} selected></option>
                {repartidores.map((item) => (
                  <option value={item.idUsuario}>
                    {item.persona.nombres +
                      " " +
                      item.persona.apellidoPaterno +
                      " " +
                      item.persona.apellidoMaterno}
                  </option>
                ))}
              </Select>
            </div>
            <div className="my-auto">
              <Label
                htmlFor="tipoPago"
                value="¿Requiere Entrega?"
                className="dark:text-gray-800 pr-4"
              />
              <Checkbox
                ref={checkRepartidor}
                onChange={(e) => handleCheckRepartidor(e)}
              />
            </div>
          </div>
        </div>
        <div className="p-6 space-y-6">
          {/* Detalle nuevo */}
          <div>
            <h3 className="text-lg font-medium text-gray-800 mb-2 dark:text-gray-800">
              Agregar Detalle
            </h3>
            <div className="grid grid-cols-4 gap-4 items-center">
              {/* <TextInput
                id="nombreProducto"
                type="text"
                placeholder="Producto o servicio"
                autoComplete="off"
                className="col-span-2"
                onChange={(e) =>
                  setNuevoDetalle({ ...nuevoDetalle, producto: e.target.value })
                }
              /> */}
              <Select
                id="nombreProducto"
                className="col-span-2"
                onChange={(e) =>
                  setNuevoDetalle({ ...nuevoDetalle, producto: e.target.value })
                }
              >
                <option value={"default"} selected></option>
                {producto.map((item) => (
                  <option value={item.idProducto}>{item.nombreProducto}</option>
                ))}
              </Select>
              <TextInput
                id="nombreProducto"
                type="text"
                placeholder="Cantidad"
                autoComplete="off"
                onChange={(e) =>
                  setNuevoDetalle({
                    ...nuevoDetalle,
                    cantidad: +e.target.value,
                  })
                }
              />
              <TextInput
                id="nombreProducto"
                type="text"
                placeholder="Precio"
                autoComplete="off"
                onChange={(e) =>
                  setNuevoDetalle({ ...nuevoDetalle, precio: +e.target.value })
                }
              />
            </div>
            <Button
              onClick={agregarDetalle}
              className="mt-4 w-full rounded-md shadow-md transition"
            >
              Agregar al detalle
            </Button>
          </div>

          {/* Lista de detalles */}
          <div>
            <h3 className="text-lg font-medium text-gray-800 mb-2 dark:text-gray-800">
              Detalles de la Venta
            </h3>
            {detalles.length === 0 ? (
              <p className="text-gray-500">No hay detalles añadidos.</p>
            ) : (
              <table className="w-full text-left border border-gray-200 dark:text-white">
                <thead>
                  <tr className="bg-gray-50 dark:bg-gray-600">
                    <th className="px-4 py-2">Producto</th>
                    <th className="px-4 py-2">Cantidad</th>
                    <th className="px-4 py-2">Precio</th>
                    <th className="px-4 py-2">Subtotal</th>
                    <th className="px-4 py-2">Acciones</th>
                  </tr>
                </thead>
                <tbody>
                  {detalles.map((detalle, index) => (
                    <tr key={index} className="border-t dark:text-gray-800">
                      <td className="px-4 py-2">{detalle.producto}</td>
                      <td className="px-4 py-2">{detalle.cantidad}</td>
                      <td className="px-4 py-2">{detalle.precio.toFixed(2)}</td>
                      <td className="px-4 py-2">
                        {(detalle.cantidad * detalle.precio).toFixed(2)}
                      </td>
                      <td className="px-4 py-2">
                        <button
                          onClick={() => eliminarDetalle(index)}
                          className="text-red-500 hover:underline"
                        >
                          Eliminar
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>

          {/* Total de la venta */}
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-800">
              Total: {totalVenta.toFixed(2)}
            </h3>
            <button
              onClick={() => {
                submitForm();
              }}
              className="bg-green-600 text-white px-4 py-2 rounded-md shadow-md hover:bg-green-700 transition"
            >
              Registrar Venta
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NewVenta;
