export interface ICategoria {
    idCategoria: number
    nombreCategoria: string
    descripcion: string
    fecRegistro: string
    codEstado: string
}