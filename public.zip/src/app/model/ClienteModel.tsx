export interface ICliente {
  idCLiente: number | null
  persona: IPersona;
  fecRegistro: string;
  codEstado: string;
}

export interface IPersona {
  idPersona: number;
  nombres: string;
  apellidoPaterno: string;
  apellidoMaterno: string;
  apellidoCasada: string;
  direccion: string;
  codEstadoCivil: string;
  codTipoIdentificacion: string;
  numeroIdentificacion: string;
  numeroContacto: string;
  fecRegistro: string;
  codEstado: string;
}
