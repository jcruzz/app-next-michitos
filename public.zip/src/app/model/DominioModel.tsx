export interface IDominioFijo {
  idDominioFijo: number;
  idDefDominio: number;
  nombreDominio: string;
  auxiliar: string;
  codDominio: string;
  descripcionDominio: string;
  fecRegistro: string;
  codEstado: string;
}
