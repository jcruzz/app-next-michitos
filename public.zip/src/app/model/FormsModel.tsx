export type IFormProducto ={
    nombreProducto: string
    cantidadstock: number
    precioProducto: number
    descripcion: string
    costoProducto: number
    codUnidadMedida: string
    imagenReferencial: string
    categorias: string
    proveedor: string
}