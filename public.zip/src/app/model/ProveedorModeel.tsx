export interface IProveedor {
  idProveedor: number;
  nombreProveedor: string;
  codTipoIdentificacion: string;
  numeroIdentificacion: string;
  numeroContacto: string;
  fecRegistro: string;
  codEstado: string;
}
