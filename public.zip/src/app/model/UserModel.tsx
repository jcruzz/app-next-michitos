export interface IResponeUserData {
  idUsuario: number;
  emailUsuario: string;
  username: string;
  roles: IResponseListRol[];
}

export interface IResponseListRol {
  idRol: number;
  nombreRol: string;
}

export interface IDataUser {
  idUsuario: number;
  emailUsuario: string;
  username: string;
  roles: IRol[];
}

export interface IRol {
  idRol: number;
  nombreRol: string;
}
