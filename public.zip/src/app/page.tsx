import Image from "next/image";
import HeaderUnAuth from "./components/header/HeaderUnAuth";

export default function Home() {
  return <HeaderUnAuth />;
}
