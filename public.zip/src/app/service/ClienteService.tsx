import axios from "axios";
import { obtainApiUrl, obtenerCabecera } from "../utils/Utils";
import { ICliente } from "../model/VentaModel";

export const obtenerCliente = async () => {
  try {
    const API = await obtainApiUrl();
    const response = await axios.get<ICliente[]>(
      API + "/api/cliente/",
      obtenerCabecera()
    );
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const obtenerClienteById = async (idCliente: number) => {
  try {
    const API = await obtainApiUrl();
    const response = await axios.post<ICliente>(
      API + "/api/cliente/obtain-cliente",
      { idVenta: idCliente },
      obtenerCabecera()
    );
    return response.data;
  } catch (error) {
    throw error;
  }
};
