import axios from "axios";
import { obtainApiUrl, obtenerCabecera } from "../utils/Utils";
import { IDominioFijo } from "../model/DominioModel";

export const obtenerDominioUnidadMedida = async () => {
  try {
    const API = await obtainApiUrl();
    const response = await axios.post<IDominioFijo[]>(
      API + "/api/dominio/",
      { idVenta: 8 },
      obtenerCabecera()
    );
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const obtenerDominioMetodoPago = async () => {
  try {
    const API = await obtainApiUrl()
    const response = await axios.post<IDominioFijo[]>(
      API + "/api/dominio/",
      { idVenta: 2 },
      obtenerCabecera()
    )
    return response.data
  } catch (error) {
    throw error
  }
}

export const obtenerTipoVenta = async () => {
  try {
    const API = await obtainApiUrl()
    const response = await axios.post<IDominioFijo[]>(
      API + "/api/dominio/",
      { idVenta: 5 },
      obtenerCabecera()
    )
    return response.data
  } catch (error) {
    throw error
  }
}

export const obtenerEstadosEntrega = async () => {
  try {
    const API = await obtainApiUrl()
    const response = await axios.post<IDominioFijo[]>(
      API + "/api/dominio/",
      { idVenta: 6 },
      obtenerCabecera()
    )
    return response.data
  } catch (error) {
    throw error
  }
}