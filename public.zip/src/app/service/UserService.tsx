import axios from "axios";
import { obtainApiUrl, obtenerCabecera } from "../utils/Utils";
import { IDataUser } from "../model/UserModel";
import { getSession } from "@/auth/Auth";
import { IUser } from "../model/VentaModel";

export const obtenerDatosUsuario = async () => {
  try {
    const API = await obtainApiUrl();
    const response = await axios.post<IUser>(
      API + "/api/user/",
      { username: getSession().userLogged },
      obtenerCabecera()
    );
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const obtenerUsuarios = async () => {
  try {
    const API = await obtainApiUrl();
    const response = await axios.get<IUser[]>(
      API + "/api/user/usuarios",
      obtenerCabecera()
    );
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const obtenerUsuarioPorId = async (idUsuario: number) => {
  try {
    const API = await obtainApiUrl();
    const response = await axios.post<IUser>(
      API + "/api/user/obtener-usuario",
      { idVenta: idUsuario },
      obtenerCabecera()
    );
    return response.data;
  } catch (error) {
    throw error;
  }
}