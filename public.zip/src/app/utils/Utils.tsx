import axios from "axios";
import { IUrlApi } from "../model/UtilModel";
import { getSession } from "@/auth/Auth";
import { Badge } from "flowbite-react";

export const obtainApiUrl = async () => {
  const response = await axios.get<IUrlApi>("/pages/api/data");
  return response.data.NEXT_PUBLIC_API_URL;
};

export const obtenerCabecera = () => {
  const token = getSession().token;
  const headers = {
    Authorization: "Bearer " + token,
  };

  const options = {
    headers: headers,
  };

  return options;

  // const token = cookies().get('user-token');
};

export const formatRol = (rol: string) => {
  if (rol !== undefined) {
    switch (rol) {
      case "ROLE_USER":
        return "Rol Usuario";
      case "ROLE_MODERATOR":
        return "Rol Moderador";
      case "ROLE_ADMIN":
        return "Rol Administrador";
      default:
        return "";
    }
  }
};

export const obtenerNombreDominio = (cod: string) => {
  switch (cod) {
    case "PEN":
      return "Pendiente";
    case "PRO":
      return "En Proceso";
    case "COM":
      return "Completada";
    default:
      return "";
  }
};

export const obtenerEstado = (cod: string) => {
  switch (cod) {
    case "COM":
      return (
        <div className="px-3">
          <Badge color="success">Completado</Badge>
        </div>
      );
    case "PEN":
      return (
        <div className="px-3">
          <Badge color="warning">Pendiente</Badge>
        </div>
      );
    case "PRO":
      return (
        <div className="px-3">
          <Badge color="info">En Camino</Badge>
        </div>
      );

    default:
      break;
  }
};
